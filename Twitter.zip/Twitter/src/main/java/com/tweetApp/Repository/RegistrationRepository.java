package com.tweetApp.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.tweetApp.model.Registration;

@Repository
public interface RegistrationRepository extends MongoRepository<Registration,Integer> {
	
	Optional<Registration> findByemail(String email);
	
	List<Registration> findAll();

}

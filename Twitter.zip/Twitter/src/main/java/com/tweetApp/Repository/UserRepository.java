package com.tweetApp.Repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweetApp.model.Registration;

public interface UserRepository extends MongoRepository<Registration, Integer> {

	public Registration findByemail(String email);

	public Registration findById(int id);

}

package com.tweetApp.model;


import java.util.List;

import org.springframework.data.annotation.Id;

public class Tweet {
	
	
	private int id;
	
	private String tweetDesc;
	
	private String tweetTag;
	
	private String Date;
	
	private String email;
	
	//private char recordActive;
	
	private List<Reply> reply;

	public void setReply(List<Reply> reply) {
		this.reply = reply;
	}

	public List<Reply> getReply() {
		return reply;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTweetDesc() {
		return tweetDesc;
	}

	public void setTweetDesc(String tweetDesc) {
		this.tweetDesc = tweetDesc;
	}

	public String getTweetTag() {
		return tweetTag;
	}

	public void setTweetTag(String tweetTag) {
		this.tweetTag = tweetTag;
	}

	public String getDate() {
		return Date;
	}

	public void setDate(String date) {
		Date = date;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	@Override
	public String toString() {
		return "Tweet [id=" + id + ", tweetDesc=" + tweetDesc + ", tweetTag=" + tweetTag + ", Date="
				+ Date + ", email=" + email + ", reply=" + reply + "]";
	}

//	public char getRecordActive() {
//		return recordActive;
//	}
//
//	public void setRecordActive(char recordActive) {
//		this.recordActive = recordActive;
//	}

	

	

	
	

	

}

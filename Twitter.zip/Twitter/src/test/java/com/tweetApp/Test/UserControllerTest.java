package com.tweetApp.Test;


import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;


import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.tweetApp.Service.UserService;
import com.tweetApp.ServiceImpl.UserServiceImpl;
import com.tweetApp.controller.UserController;
import com.tweetApp.dto.LoginResponse;
import com.tweetApp.dto.ResetPasswordRequestDTO;
import com.tweetApp.dto.UserList;
import com.tweetApp.dto.UserTweetsDTO;
import com.tweetApp.model.Registration;



@ExtendWith(MockitoExtension.class)
public class UserControllerTest {

	private MockMvc mockMvc;

	@Mock
	private UserService userServiceMock = new UserServiceImpl();

	@InjectMocks
	private UserController userController;

	Registration registration = new Registration();

	String requestJson = "{\"email\":\"s@gmail.com\",\"firstName\":\"sh\",\"lastName\":\"jaiswal\",\"password\":\"124\",\"gender\":\"female\",\"contactNo\":\"987677855\"}";

	String responseJson = "{\"id\":1,\"firstName\":\"sh\",\"lastName\":\"jaiswal\",\"gender\":\"female\",\"email\":\"s@gmail.com\",\"password\":\"124\",\"errorMessage\":null,\"sucessMessage\":null}";
	String loginResponseJson="{\"email\":\"s@gmail.com\",\"errorMessage\":null}";
	
	String resetPasswordResJson="{\"errorMessage\":null,\"successMessage\":\"Password Updated Successfully\"}";
	
	@SuppressWarnings("deprecation")
	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = MockMvcBuilders.standaloneSetup(userController).build();
		ObjectMapper objectMapper = new ObjectMapper();
		try {
			this.registration = objectMapper.readValue(requestJson, Registration.class);

		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	@Test
	public void registerPositiveTest() throws Exception {

		Registration registrationDto = new Registration();
		registrationDto.setId(1);
		registrationDto.setEmail("s@gmail.com");
		registrationDto.setFirstName("sh");
		registrationDto.setLastName("jaiswal");
		registrationDto.setPassword("124");
		registrationDto.setGender("female");

		String requestJson = "{\"id\":\"1\",\"email\":\"s@gmail.com\",\"firstName\":\"sh\",\"lastName\":\"jaiswal\",\"password\":\"124\",\"gender\":\"female\"}";

		
		
		String url = "/api/v1.0/tweets/register";

		when(userServiceMock.add(Mockito.any())).thenReturn("success");
		MockHttpServletResponse response = mockMvc
				.perform(post(url).accept(MediaType.APPLICATION_JSON).content(requestJson)
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andReturn().getResponse();

		assertEquals(responseJson, response.getContentAsString());

	}

	@Test
	public void registerNegativeTest() throws Exception {

		String url = "/api/v1.0/tweets/register";

		when(userServiceMock.add(Mockito.any())).thenReturn(null);
		MockHttpServletResponse response = mockMvc
				.perform(post(url).accept(MediaType.APPLICATION_JSON).content(requestJson)
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andReturn().getResponse();

		assertEquals("", response.getContentAsString());

	}
	
	@Test
	public void LoginPositiveTest() throws Exception {
		String url = "/api/v1.0/tweets/login";
		LoginResponse loginResponseDTO = new LoginResponse();
		loginResponseDTO.setEmail("fse@gmail.com");
		loginResponseDTO.setStatus(true);
		String loginReqJson="{\"email\":\"s@gmail.com\",\"password\":\"124\"}";
		when(userServiceMock.Login(Mockito.any())).thenReturn(loginResponseDTO);
		MockHttpServletResponse response = mockMvc
				.perform(post(url).accept(MediaType.APPLICATION_JSON).content(loginReqJson)
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andReturn().getResponse();

		assertEquals(loginResponseJson, response.getContentAsString());
		
	}
	
	@Test
	public void ResetPasswordPositiveFlow() throws Exception{
		String url = "/api/v1.0/tweets/reset";
		ResetPasswordRequestDTO resetPasswordResponseDTO=new ResetPasswordRequestDTO();
		resetPasswordResponseDTO.setSuccesmessage("Password Updated Successfully");
		
		String resetPasswordReqJson="{\"emailId\":\"s@gmail.com\",\"newpassword\":\"122\",\"oldpassword\":\"124\"}";
		
		when(userServiceMock.resetpassword(Mockito.any())).thenReturn(resetPasswordResponseDTO);
		MockHttpServletResponse response = mockMvc
				.perform(put(url).accept(MediaType.APPLICATION_JSON).content(resetPasswordReqJson)
						.contentType(MediaType.APPLICATION_JSON).accept(MediaType.APPLICATION_JSON))
				.andReturn().getResponse();

		assertEquals(resetPasswordResJson, response.getContentAsString());
		
	}
	
	@Test
	public void getAllUsersPositiveFlow() throws Exception{
		String url="/api/v1.0/tweets/getallUsers";
		List<UserList> userDTOList= new ArrayList<>();
		UserList userDTO= new UserList();
		userDTO.setEmail("s@gmail.com");
		userDTO.setFirstName("sh");
		userDTO.setGender("female");
		userDTO.setId(1);
		userDTOList.add(userDTO);
		
		String expectedJson="[{\"id\":1,\"email\":\"s@gmail.com\",\"firstName\":\"sh\",\"gender\":\"female\"}]";
		
		when(userServiceMock.getAllUsers()).thenReturn(userDTOList);
		MockHttpServletResponse response = mockMvc.perform(get(url).accept(MediaType.APPLICATION_JSON)).andReturn().getResponse();
		assertEquals(expectedJson, response.getContentAsString());
	}
	
	@Test
	public void getUsersTweetsPositiveFlow() throws Exception{
		String url="/api/v1.0/tweets/UsersTweet/?email=fse@gmail.com";
		List<UserTweetsDTO> userTweetsDTOList= new ArrayList<>();
		UserTweetsDTO userTweetsDTO= new UserTweetsDTO();
		userTweetsDTO.setTweetId(1);
		userTweetsDTO.setTweetDesc("desc");
		userTweetsDTOList.add(userTweetsDTO);
		
		String expectedJson="[{\"tweetId\":1,\"tweetDesc\":\"desc\",\"replyDTOList\":null,\"date\":null}]";
		when(userServiceMock.getUsersTweet(Mockito.any())).thenReturn(userTweetsDTOList);
		MockHttpServletResponse response = mockMvc.perform(get(url).accept(MediaType.APPLICATION_JSON)).andReturn().getResponse();
		assertEquals(expectedJson, response.getContentAsString());
	}
	
	

}

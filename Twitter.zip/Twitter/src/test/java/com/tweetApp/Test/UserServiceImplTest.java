package com.tweetApp.Test;


import org.mockito.InjectMocks;

import com.tweetApp.Repository.RegistrationRepository;
import com.tweetApp.Repository.ReplyRepository;
import com.tweetApp.Repository.TweetRepository;
import com.tweetApp.Repository.UserRepository;
import com.tweetApp.ServiceImpl.UserServiceImpl;
import com.tweetApp.dto.LoginRequest;
import com.tweetApp.dto.LoginResponse;
import com.tweetApp.dto.ReplyDTO;
import com.tweetApp.dto.ResetPasswordRequestDTO;
import com.tweetApp.dto.UserTweetsDTO;
import com.tweetApp.model.Registration;
import com.tweetApp.model.Reply;
import com.tweetApp.model.Tweet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class UserServiceImplTest {
	
	private MockMvc mockMvc;
	
	@Mock
	private UserRepository userrepo;
	
	@Mock
	private RegistrationRepository registerrepo;
	
	@Mock
	private TweetRepository tweetRepo;
	
	@Mock
	private ReplyRepository replyRepo;
	
	@InjectMocks
	private UserServiceImpl userServiceMock=new UserServiceImpl();
	
	@BeforeEach
	public void setup() {

		MockitoAnnotations.initMocks(this);
	}
	
	@Test
	public void registerPositiveTest() throws Exception {
		Registration registration = new Registration();
		registration.setId(1);
		registration.setEmail("s@gmail.com");
		registration.setFirstName("sh");
		registration.setLastName("jaiswal");
		registration.setPassword("124");
		registration.setGender("female");
		registration.setContactNo(null);
		
		String expected="succes";
		
		when(userrepo.findByemail("s@gmail.com")).thenReturn(null);
		
		//when(userrepo.findById(1)).thenReturn(null);
		String actualresp=userServiceMock.add(registration);
		
		assertEquals(expected,actualresp);
	}
	
	@Test
	public void registerNegativeTest() throws Exception {
		
		Registration registration = new Registration();
		String expectedres ="EmailId Already Exists";
//		registration.setId(1);
//		registration.setEmail("fse@gmail.com");
//		RegistrationDto registrationDto=new RegistrationDto();
//		registrationDto.setId(1);
//		registrationDto.setEmail("fse@gmail.com");
//		
		Registration resgister=new Registration();
		resgister.setEmail("s@gmail.com");
		resgister.setId(1);
		
		when(userrepo.findByemail("s@gmail.com")).thenReturn(resgister);
		
		when(userrepo.findById(1)).thenReturn(resgister);
		
		String actualresp=userServiceMock.add(resgister);
		
		assertEquals(expectedres,actualresp);
		
	}
	
	@Test
	public void signUpPostiveTest() throws Exception{
		LoginRequest loginRequest=new LoginRequest();
		loginRequest.setEmail("s@gmail.com");
		loginRequest.setPassword("124");
		
		LoginResponse expected=new LoginResponse();
		//expected.setStatus(true);
		expected.setEmail("s@gmail.com");
		Registration registration=new Registration();
		registration.setEmail("s@gmail.com");
		registration.setPassword("124");
		
		when(userrepo.findByemail("s@gmail.com")).thenReturn(registration);
		
		LoginResponse actual=userServiceMock.Login(loginRequest);
		assertEquals(expected,actual);
	}
	
	@Test
	public void signUpElseTest() throws Exception{
		LoginRequest loginRequest=new LoginRequest();
		loginRequest.setEmail("s@gmail.com");
		loginRequest.setPassword("111");
		
		LoginResponse expected=new LoginResponse();
		//expected.setStatus(false);
		expected.setErrorMessage("Incorrect UserName/Password");
		Registration registration=new Registration();
		registration.setEmail("s@gmail.com");
		registration.setPassword("124");
		
		when(userrepo.findByemail("s@gmail.com")).thenReturn(registration);
		
		LoginResponse actual=userServiceMock.Login(loginRequest);
		assertEquals(expected,actual);
	}
	
//	@Test
//	public void signUpNullTest() throws Exception{
//		LoginRequestDTO loginRequestDTO=new LoginRequestDTO();
//		loginRequestDTO.setEmail("fse@gmail.com");
//		loginRequestDTO.setPassword("passs");
//		
//		LoginResponseDTO expected=new LoginResponseDTO();
//		expected.setStatus(false);
//		expected.setErrorMessage("Incorrect UserName/Password");
//		
//		when(userrepo.findByemail("fse@gmail.com")).thenReturn(null);
//		
//		LoginResponseDTO actual=userServiceMock.signUp(loginRequestDTO);
//		assertEquals(expected,actual);
//	}
	
	@Test
	public void resetpasswordPositiveTest() throws Exception{
		
		ResetPasswordRequestDTO resetRequest=new ResetPasswordRequestDTO();
		resetRequest.setOldpassword("124");
		resetRequest.setNewpassword("122");
		resetRequest.setEmail("s@gmail.com");
		
	//	ResetPasswordResponseDTO expected = new ResetPasswordResponseDTO();
		resetRequest.setSuccesmessage("Password Updated Successfully");
		
		Registration registration= new Registration();
		registration.setEmail("fse@gmail.com");
		registration.setPassword("old");
		
		when(registerrepo.findByemail("fse@gmail.com")).thenReturn(Optional.of(registration));
		
		ResetPasswordRequestDTO actual=userServiceMock.resetpassword(resetRequest);
		assertEquals(resetRequest,actual);
	}
	
	@Test
	public void resetpasswordElseTest() throws Exception{
		
		ResetPasswordRequestDTO resetRequest=new ResetPasswordRequestDTO();
		resetRequest.setOldpassword("122");
		resetRequest.setNewpassword("122");
		resetRequest.setEmail("s@gmail.com");
		
		ResetPasswordRequestDTO expected = new ResetPasswordRequestDTO();
		resetRequest.setErrormessage("Entered Old Password is Incorrect");
		
		Registration registration= new Registration();
		registration.setEmail("fse@gmail.com");
		registration.setPassword("old");
		
		when(registerrepo.findByemail("s@gmail.com")).thenReturn(Optional.of(registration));
		
		ResetPasswordRequestDTO actual=userServiceMock.resetpassword(resetRequest);
		assertEquals(expected,actual);
	}
	
	
	
	

}
